using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HotelWebApp.Pages.Admin
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
